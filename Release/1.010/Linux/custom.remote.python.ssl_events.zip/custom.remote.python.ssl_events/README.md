"# activegate_python_ssl_plugin" 

This plugin checks the SSL certificates of host in the hosts.txt file and logs problems on Dyantrace if the certificate is aout to expire.
